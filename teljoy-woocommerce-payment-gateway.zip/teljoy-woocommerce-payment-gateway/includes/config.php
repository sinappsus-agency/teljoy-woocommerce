<?php
$environments = array();
$environments["sandbox"]     =    array(
    "api_url"    =>    "https://pay.staging.teljoy.co.za/api/",
);

$environments["production"] =    array(
    "api_url"    =>    "https://pay.teljoy.co.za/api/",
);

//https://pay.staging.teljoy.co.za/api/
//https://pay.teljoy.co.za/api/